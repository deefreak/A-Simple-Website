var express = require("express");
var app = express();
var bodyParser = require("body-parser");
var mongoose = require("mongoose");
var flash = require("connect-flash");
var Campground = require("./models/campground");
var seedDB = require("./seeds");
var Comment = require("./models/comment");
var passport = require("passport");
var LocalStrategy = require("passport-local");
var methodOverride = require("method-override");
var User = require("./models/user");
var commentRoutes = require("./routes/comments");
var campgroundRoutes = require("./routes/campgrounds");
var indexRoutes = require("./routes/index");


//seedDB();

/*mongoose.connect("mongodb://localhost/yelp_camp",{
	useNewUrlParser: true,
	useUnifiedTopology: true,
	useCreateIndex: true,
	useFindAndModify: false
});*/
mongoose.connect("mongodb+srv://dee_freak:ihavetowin@cluster0-x3wyt.mongodb.net/yelp_camp?retryWrites=true&w=majority",{
	useNewUrlParser: true,
	useUnifiedTopology: true,
	useCreateIndex: true,
	useFindAndModify: false
});

app.use(bodyParser.urlencoded({extended: true}));

app.set("view engine","ejs");
app.use(express.static(__dirname + "/public"))
app.use(methodOverride("_method"));
app.use(flash());

//PASSPORT CONFIGURATION
app.use(require("express-session")({
	secret: "Once again Rusty wins cutest Dog",
	resave: false,
	saveUninitialized: false
}));

app.use(passport.initialize());
app.use(passport.session());
passport.use(new LocalStrategy(User.authenticate()));
passport.serializeUser(User.serializeUser());
passport.deserializeUser(User.deserializeUser());

app.use(function(req,res,next){
	res.locals.currentUser = req.user;
	res.locals.error = req.flash("error");
	res.locals.success = req.flash("success");
	next();
});

app.use(indexRoutes);
app.use(campgroundRoutes);
app.use(commentRoutes);


/*Campground.create({
	name: "Granite Hill", 
	image: "https://pixabay.com/get/57e1d14a4e52ae14f1dc84609620367d1c3ed9e04e5074417c2973d69e44c1_340.jpg",
	description: "This is a huge granite hill. No bathrooms. no water. Beautiful Granite!"
	},
	function(err,campground){
	if(err){
		console.log(err);
	}else{
		console.log("Newly Created Campground");
		console.log(campground);
	}
});

var campgrounds = [
		{name: "Salmon Creek", image: "https://pixabay.com/get/52e8d4444255ae14f1dc84609620367d1c3ed9e04e5074417c2973d69e44c1_340.jpg"},
		{name: "Granite Hill", image: "https://pixabay.com/get/57e1d14a4e52ae14f1dc84609620367d1c3ed9e04e5074417c2973d69e44c1_340.jpg"},
		{name: "Mountain Goat's Rest", image: "https://pixabay.com/get/54e5dc474355a914f1dc84609620367d1c3ed9e04e5074417c2973d69e44c1_340.jpg"},
	{name: "Salmon Creek", image: "https://pixabay.com/get/52e8d4444255ae14f1dc84609620367d1c3ed9e04e5074417c2973d69e44c1_340.jpg"},
		{name: "Granite Hill", image: "https://pixabay.com/get/57e1d14a4e52ae14f1dc84609620367d1c3ed9e04e5074417c2973d69e44c1_340.jpg"},
		{name: "Mountain Goat's Rest", image: "https://pixabay.com/get/54e5dc474355a914f1dc84609620367d1c3ed9e04e5074417c2973d69e44c1_340.jpg"}
];*/	

app.listen(process.env.PORT,process.env.IP,function(){
	console.log("The Yelpcamp Server has Started");
});